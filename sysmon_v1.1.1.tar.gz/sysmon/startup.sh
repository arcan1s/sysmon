#!/bin/bash

# Autostart SysMon on KDE4 startup
