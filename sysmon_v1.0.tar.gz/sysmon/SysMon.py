#!/usr/bin/python2.7
# -*- coding: utf-8 -*-

import argparse,  os,  shutil

if __name__ == '__main__':
    
    parser = argparse.ArgumentParser(description='Create and install SysMon by arcanis')
    
    parser.add_argument('-v','--version', dest='ver',
            help = 'Show version and exit',
            action='store_true', default = False)
    
    parser.add_argument('-l','--lang', dest='lang',
            help = 'Language (eng/rus), default is "eng"',
            action='store', default = 'eng')
    
    parser.add_argument('-d','--directory', dest='dir',
            help = 'Path to install, default is current directory',
            action='store', default = False)

    parser.add_argument('-s','--startup', dest='startup',
            help = 'Enable autostart on KDE4 startup. It must be something like "~/,kde4/Autostart". Default is False',
            action='store', default = False)
    
    parser.add_argument('-a','--amarok', dest='amarok',
            help = 'Disable amarok bar, default is True',
            action='store_false', default = True)
    
    parser.add_argument('-n1','--net1', dest='net1',
            help = 'Name of first network interface, default is "eth0"',
            action='store', default = 'eth0')
    
    parser.add_argument('-n2','--net2', dest='net2',
            help = 'Name of second network interface, default is "eth1"',
            action='store', default = 'eth1')
    
    parser.add_argument('-hdd','--harddisk', dest='hdd',
            help = 'Name of hard disk drive device, default is "/dev/sda"',
            action='store', default = '/dev/sda')

    parser.add_argument('-c','--cpuinfo', dest='cpu',
            help = 'File with cpu information, default is "/proc/cpuinfo"',
            action='store', default = '/proc/cpuinfo')
    
    args = parser.parse_args()
    
    
    if (args.ver):
        print ("                      System Monitor")
        print ("System information and hardware monitor based on EG Sysmon")
        print ("Version : 1.0                                License : GPL")
        print ("                                                by arcanis")
        print ("                              E-mail : esalexeev@gmail.com")


    else:
        with open("sysmon.theme", 'w') as theme:
            if (args.amarok):
                theme.write("karamba x=1366 y=768 w=300 h=620 locked=true\n")
            else:
                theme.write("karamba x=1366 y=768 w=300 h=510 locked=true\n")
            theme.write("defaultfont font=\"Arial\" fontsize=10 color=255,255,255\nimage x=15 y=4 path=\"img/bckgrnd.png\"\n\x23\nimage x=10 y=3 path=\"img/ligne.png\"\n")

            theme.write("\x23\n\x23 System group\n\x23\n<group> x=0 y=7\n  image x=33 y=35 path=\"icones/sysinfo.png\"\n")
            theme.write("  text x=160 y=10 value=\"")
            if (args.lang=="rus"):
                line=u"Информация о Системе"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="System Informantion"
                theme.write(line)
            theme.write("\" fontsize=14 font=\"Arial\" color=70,216,29 align=center\n\x23\n  text x=85 y=35  value=\"")
            if (args.lang=="rus"):
                line=u"Пользователь"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="User"
                theme.write(line)
            theme.write(" :\" fontsize=12 font=\"Arial\" color=255,255,255 align=left\n")
            theme.write("  text x=290 y=35 sensor=program program=\"echo ${USER}\" line=1 fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right\n")
            theme.write("  text x=85 y=53 value=\"")
            if (args.lang=="rus"):
                line=u"Аптайм"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="Uptime"
                theme.write(line)
            theme.write(" :\" fontsize=12 font=\"Arial\" color=255,255,255 align=left\n")
            theme.write("  text x=290 y=53 sensor=uptime format=\"%d Day(s) %Hh%Mmin\" line=1 fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right\n")
            theme.write("  text x=85 y=71 value=\"Kernel :\" fontsize=12 font=\"Arial\" color=255,255,255 align=left\n")
            theme.write("  text x=290 y=71 sensor=program program=\"uname -r\" line=1 fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right\n</group>\n\x23\nimage x=10 y=95 path=\"img/ligne.png\"\n\x23\n")
            
            theme.write("\x23 CPU Group & HDD temp\n\x23\n<group> x=0 y=100\n  image x=27 y=70 path=\"icones/cpu.png\"\n  text x=160 y=10 value=\"CPU & HDD\" fontsize=14 font=\"Arial\" color=70,216,29 align=center\n\x23\n")
            theme.write("  text x=160 y=30 sensor=program program=\"cat ")
            theme.write(args.cpu)
            theme.write(" | grep 'model name' | sed -e 's/.*: //'\" line=1 fontsize=10 font=\"Droid Sans Mono\" color=255,255,255 align=center\n")
            theme.write("  text x=97 y=48 value=\"")
            if (args.lang=="rus"):
                line=u"Температура"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="Temperature"
                theme.write(line)
            theme.write(" :\" align=left fontsize=12 font=\"Arial\" color=255,255,255\n")
            theme.write("  text x=290 y=48 sensor=program program=\"sensors | grep  'high' | awk '{print $2 }'\"  fontsize=12 font=\"Droid Sans Mono\"  interval=50000 color=255,255,255 align=right\n")
            theme.write("  text x=97 y=63 value=\"")
            if (args.lang=="rus"):
                line=u"Температура HDD"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="HDD temperature"
                theme.write(line)
            theme.write(" :\" align=left fontsize=12 font=\"Arial\" color=255,255,255\n")
            theme.write("  text x=290 y=63 sensor=program program=\"hddtemp ")
            theme.write(args.hdd)
            theme.write(" | awk '{print $4}'\"  fontsize=12 font=\"Droid Sans Mono\"  interval=50000 color=255,255,255 align=right\n\x23\n")
            theme.write("  image x=103 y=85 path=\"img/cpugrille.png\"\n  graph x=103 y=85 w=177 h=23 sensor=cpu cpu=0 interval=2000 color=53,229,82\n  graph x=103 y=85 w=177 h=23 sensor=cpu cpu=1 interval=2000 color=255,0,0\n\x23\n")
            theme.write("  text x=97 y=115 value=\"Core 0 : \" fontsize=12 font=\"Arial\" color=53,229,82 align=left\n  text x=190 y=115 sensor=cpu cpu=0 format=\"%v%\" align=right fontsize=12 font=\"Droid Sans Mono\" color=53,229,82 interval=2000 aligh=right\n")
            theme.write("  text x=197 y=115 value=\"Core 1 :\"  fontsize=12 font=\"Arial\" color=255,0,0 align=left\n  text x=290 y=115 sensor=cpu cpu=1 format=\"%v%\" align=right fontsize=12 font=\"Droid Sans Mono\" color=255,0,0 interval=2000 align=right\n")
            theme.write("  text x=97 y=130 value=\"MHz :\"  fontsize=12 font=\"Arial\" color=255,255,255 align=left\n  text x=190 y=130 sensor=program program=\"cat ")
            theme.write(args.cpu)
            theme.write(" | grep MHz | awk '{print $4}' | cut -c -6 | head -n1\" align=right fontsize=12 font=\"Droid Sans Mono\" color=53,229,82 interval=2000 aligh=right\n  text x=290 y=130 sensor=program program=\"cat ")
            theme.write(args.cpu)
            theme.write(" | grep MHz | awk '{print $4}' | cut -c -6 | tail -n1\" align=right fontsize=12 font=\"Droid Sans Mono\" color=255,0,0 interval=2000 aligh=right\n  text x=97 y=145 value=\"")
            if (args.lang=="rus"):
                line=u"Общая загрузка"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="All"
                theme.write(line)
            theme.write(" :\"  fontsize=12 font=\"Arial\" color=255,255,255 align=left\n  text x=290 y=145 sensor=cpu cpu=all format=\"%v%\" align=right fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 interval=2000 align=right\n")
            theme.write("</group>\n\x23\nimage x=10 y=260 path=\"img/ligne.png\"\n\x23\n")
            
            theme.write("\x23 Memory\n\x23\n<group> x=0 y=270\n  image x=25 y=35 path=\"icones/memoire.png\"\n  text x=160 y=5 value=\"")
            if (args.lang=="rus"):
                line=u"Память"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="Memory"
                theme.write(line)
            theme.write("\" fontsize=14 font=\"Arial\" color=70,216,29 align=center\n\x23\n  text x=130 y=25 sensor=memory format=\"%umb\"  fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right\n  text x=260 y=25 sensor=memory format=\"")
            if (args.lang=="rus"):
                line=u"из"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="of"
                theme.write(line)
            theme.write("  %tm Mb (RAM)\"  fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right\n\x23\n  image x=83 y=41 vertical=false path=\"img/jauge_fond.png\"\n")
            theme.write("  bar x=88 y=46 sensor=memory format=\"%umb\" interval=\"1000\" vertical=false path=\"img/jauge.png\" mountpoint=\"/home\"\n\x23\n  text x=125 y=60 sensor=memory format=\"%us\"  fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right\n  text x=265 y=60 sensor=memory format=\"")
            if (args.lang=="rus"):
                line=u"из"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="of"
                theme.write(line)
            theme.write("  %ts Mb (SWAP)\" fontsize=12 font=\"Droid Sans Mono\" color=255,255,255  align=right\n\x23\n  image x=83 y=77 vertical=false path=\"img/jauge_fond.png\"\n")
            theme.write("  bar x=88 y=82 sensor=memory format=\"%us\" interval=\"1000\" vertical=false path=\"img/jauge.png\" mountpoint=\"/home\"\n\x23\n</group>\n\x23\nimage x=10 y=363 path=\"img/ligne.png\"\n\x23\n")
            
            theme.write("\x23 Internet\n\x23\n<group> x=0 y=375\n  image x=32 y=50 PATH=\"icones/internet.png\"\n  text x=160 y=3 value=\"")
            if (args.lang=="rus"):
                line=u"Интернет"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="Internet"
                theme.write(line)
            theme.write("\" fontsize=14 font=\"Arial\" color=70,216,29 align=center\n\x23\n  text  x=97 y=26 value=\"IP (\" color=255,255,255 fontsize=12 font=\"Arial\" color=255,255,255 align=left\n")
            theme.write("  text  x=150 y=26 sensor=program program=\"if ! (ifconfig ")
            theme.write(args.net2)
            theme.write(" | grep 'inet ' > /dev/null); then if ! (ifconfig ")
            theme.write(args.net1)
            theme.write(" | grep 'inet ' > /dev/null); then echo lo; else echo ")
            theme.write(args.net1)
            theme.write("; fi; else echo ")
            theme.write(args.net2)
            theme.write("; fi\" color=255,255,255 fontsize=12 font=\"Arial\" color=255,255,255 align=right interval=10000\n  text  x=160 y=26 value=\"):\" color=255,255,255 fontsize=12 font=\"Arial\" color=255,255,255 align=right\n")
            theme.write("  text x=290 y=26 sensor=program program=\"NETDEV=`if ! (ifconfig ")
            theme.write(args.net2)
            theme.write(" | grep 'inet ' > /dev/null); then if ! (ifconfig ")
            theme.write(args.net1)
            theme.write(" | grep 'inet ' > /dev/null); then echo lo; else echo ")
            theme.write(args.net1)
            theme.write("; fi; else echo ")
            theme.write(args.net2)
            theme.write("; fi`; ifconfig $NETDEV | grep 'inet ' | awk '{print $2 }'\" fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right interval=10000\n  text x=97 y=41 value=\"")
            if (args.lang=="rus"):
                line=u"Внешний IP"
                theme.write(line.encode('utf-8'))
            if (args.lang=="eng"):
                line="External IP"
                theme.write(line)
            theme.write(" :\" color=255,255,255 fontsize=12 font=\"Arial\" color=255,255,255 align=left\n  text x=297 y=41 sensor=program program=\"wget http://checkip.dyndns.org/ -q -O - | awk '{print $6}' | sed 's/<.*>//g'\" interval=10000 fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right\n")
            theme.write("  text x=97 y=56 value=\"Hostname :\" fontsize=12 font=\"Arial\"  color=255,255,255 align=left\n  text x=290 y=56 sensor=program program=\"'hostname'\" color=255,255,255 fontsize=12 font=\"Droid Sans Mono\" align=right\n\x23\n  image x=101 y=75 path=\"img/grille.png\"\n")
            theme.write("  graph x=101 y=75 w=184 h=28 color=53,229,82 sensor=network device=")
            theme.write(args.net1)
            theme.write(" format=\"%in\" interval=1000 max=250\n  graph x=101 y=75 w=184 h=28 color=247,1,1 sensor=network device=")
            theme.write(args.net1)
            theme.write(" format=\"%out\" interval=1000 max=250\n  graph x=101 y=75 w=184 h=28 color=53,229,82 sensor=network device=")
            theme.write(args.net2)
            theme.write(" format=\"%in\" interval=1000 max=250\n  graph x=101 y=75 w=184 h=28 color=247,1,1 sensor=network device=")
            theme.write(args.net2)
            theme.write(" format=\"%out\" interval=1000 max=250\n\x23\n  text x=97 y=110 sensor=program program=\"if ! (ifconfig ")
            theme.write(args.net2)
            theme.write(" | grep 'inet ' > /dev/null); then if ! (ifconfig ")
            theme.write(args.net1)
            theme.write(" | grep 'inet ' > /dev/null); then echo lo; else echo ")
            theme.write(args.net1)
            theme.write("; fi; else echo ")
            theme.write(args.net2)
            theme.write("; fi\" fontsize=12 font=\"Arial\" decimals=1 color=255,255,255 align=left\n  text x=290 y=110 sensor=program program=\"NETDEV=`if ! (ifconfig ")
            theme.write(args.net2)
            theme.write(" | grep 'inet ' > /dev/null); then if ! (ifconfig ")
            theme.write(args.net1)
            theme.write(" | grep 'inet ' > /dev/null); then echo lo; else echo ")
            theme.write(args.net1)
            theme.write("; fi; else echo ")
            theme.write(args.net2)
            theme.write("; fi`; RXB=$(cat /sys/class/net/$NETDEV/statistics/rx_bytes) && TXB=$(cat /sys/class/net/$NETDEV/statistics/tx_bytes) && sleep 2 && ")
            theme.write("RXBN=$(cat /sys/class/net/$NETDEV/statistics/rx_bytes) && TXBN=$(cat /sys/class/net/$NETDEV/statistics/tx_bytes) && RXDIF=$(echo $((RXBN - RXB)) ) && TXDIF=$(echo $((TXBN - TXB)) ) && ")
            theme.write("echo -en $((RXDIF/1024/2)) && echo -n ' / ' && echo -en $((TXDIF/1024/2)) && echo ' KB/s'\" fontsize=12 font=\"Droid Sans Mono\" decimals=1 color=255,255,255 align=right interval=1000\n")
            theme.write("</group>\n\x23\nimage x=10 y=500 path=\"img/ligne.png\"\n\x23\n")
            
            if (args.amarok):
                theme.write("\x23 Amarok Bar\n\x23\n<group> x=0 y=513\n  text x=160 y=3 value=\"Amarok\" fontsize=14 font=\"Arial\" color=70,216,29 align=center\n\x23\n  text x=30 y=30 value=\"")
                if (args.lang=="rus"):
                    line=u"Композиция"
                    theme.write(line.encode('utf-8'))
                if (args.lang=="eng"):
                    line="Title"
                    theme.write(line)
                theme.write(" :\" align=left fontsize=12 font=\"Arial\" color=255,255,255\n  text x=290 y=30 sensor=program program=\"title=")
                theme.write("`qdbus org.kde.amarok /Player GetMetadata | grep -m1 title: | cut -c 7- | sed -e 's/^[ \\t]*//'`;[ `echo $title |  wc -c` -lt 20 ] && echo $title || echo `echo $title | cut -c -16`...\" fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right interval=2000\n\x23\n")
                theme.write("  text x=30 y=47 value=\"")
                if (args.lang=="rus"):
                    line=u"Исполнитель"
                    theme.write(line.encode('utf-8'))
                if (args.lang=="eng"):
                    line="Artist"
                    theme.write(line)
                theme.write(" :\" align=left fontsize=12 font=\"Arial\" color=255,255,255\n  text x=290 y=47 sensor=program program=\"artist=")
                theme.write("`qdbus org.kde.amarok /Player GetMetadata | grep -m1 artist: | cut -c 14-`;[ `echo $artist | wc -c` -lt 20 ] && echo $artist || echo `echo $artist | cut -c -16`...\" fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right interval=2000\n")
                theme.write("\x23\n  text x=30 y=64 value=\"")
                if (args.lang=="rus"):
                    line=u"Альбом"
                    theme.write(line.encode('utf-8'))
                if (args.lang=="eng"):
                    line="Album"
                    theme.write(line)
                theme.write(" :\" align=left fontsize=12 font=\"Arial\" color=255,255,255\n  text x=290 y=64 sensor=program program=\"album=")
                theme.write("`qdbus org.kde.amarok /Player GetMetadata | grep -m1 album: | cut -c 7- | sed -e 's/^[ \\t]*//'`;[ `echo $album |  wc -c` -lt 20 ] && echo $album || echo `echo $album | cut -c -18`...\" fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right interval=2000\n")
                theme.write("\x23\n  text x=30 y=81 value=\"")
                if (args.lang=="rus"):
                    line=u"Время"
                    theme.write(line.encode('utf-8'))
                if (args.lang=="eng"):
                    line="Time"
                    theme.write(line)
                theme.write(" :\" align=left fontsize=12 font=\"Arial\" color=255,255,255\n  text x=235 y=81 sensor=program program=\"milTime=")
                theme.write("`qdbus org.kde.amarok /Player PositionGet`;[ `expr length $((milTime/1000 % 60))` -lt 2 ] && echo $((milTime/60000)):0$((milTime/1000 % 60)) || echo $((milTime/60000)):$((milTime/1000 %60))\"  fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right interval=2000\n")
                theme.write("  text x=250 y=81 value=\"/\" align=right fontsize=12 font=\"Arial\" color=255.255.255\n  text x=290 y=81 sensor=program program=\"timeall=")
                theme.write("`qdbus org.kde.amarok /Player GetMetadata | grep mtime | awk '{print $2 }'`;[ `expr length $((timeall/1000 % 60))` -lt 2 ] && echo $((timeall/60000)):0$((timeall/1000 % 60)) || echo $((timeall/60000)):$((timeall/1000 %60))\"  fontsize=12 font=\"Droid Sans Mono\" color=255,255,255 align=right interval=2000\n")
                theme.write("</group>\n\x23\nimage x=10 y=610 path=\"img/ligne.png\"\n\x23")
        
        
        with open("maindata.xml",  'w') as xml:
            xml.write("<?xml version=\"2.2\" encoding=\"UTF-8\"?>\n<!DOCTYPE superkaramba_theme>\n<superkaramba_theme>\n")
            xml.write(" <themefile>sysmon.theme</themefile>\n <name>System Monitor</name>\n <icon>Logo.png</icon>\n")
            xml.write(" <description>System information and hardware monitor based on EG Sysmon. Monitors CPU, memory, network traffic (for two network devices) and amarok. </description>")
            xml.write(" <author>Evgeniy Alexeev aka arcanis</author>\n <author_email>esalexeev@gmail.com</author_email>\n")
            xml.write("\t<version>1.0</version>\n\t<license>GPL</license>\n</superkaramba_theme>")
    
    
        if (args.startup):
            
            with open("sysmon_startup.sh", 'a') as start:
                start.write("superkaramba ")
                if (args.dir):
                    path=os.path.abspath(args.dir)+"/sysmon/sysmon.theme"
                else:
                    path=os.getcwd()+"/sysmon.theme\n"
                start.write(path)
            
            tar=os.path.abspath(args.startup)
            file=os.getcwd()+"/sysmon_startup.sh"
            shutil.copy(file,  tar)


        if (args.dir):
            tar_dir=os.path.abspath(args.dir)+"/sysmon"
            cur_dir=os.getcwd()
            shutil.copytree(cur_dir, tar_dir)
            rem=tar_dir+"/SysMon.py"
            os.remove(rem)
            rem=tar_dir+"/sysmon_startup.sh"
            os.remove(rem)
